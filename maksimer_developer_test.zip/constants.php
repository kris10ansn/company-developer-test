<?php

const USERMETA_SAVED_EVENTS_KEY = "saved_events";

const EVENT_PAGE_KEY = "events_page";
const EVENT_PAGE_SIZE_KEY = "events_page_size";
const EVENT_SORT_KEY = "events_sort";
const EVENT_SORT_ORDER_KEY = "events_sort_order";
const EVENT_SAVE_KEY = "save_event";
const EVENT_UNSAVE_KEY = "unsave_event";
const EVENT_DATE_FROM_KEY = "events_date_from";
const EVENT_DATE_TO_KEY = "events_date_to";